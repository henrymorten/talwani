from test_ctk import TestCTk
from test_ctk_toplevel import TestCTkToplevel
from test_ctk_button import TestCTkButton

TestCTk().main()
TestCTkToplevel().main()
TestCTkButton().main()
